
Visualisations are very important to show and communicate findings

Hierarchical classification is represented in:
1. animal groups (clusters)

At each step of clusters, two closest clusters are merged, continue until all countries in a single cluster. This is **agglomerative** hierarchical clustering

We can use SciPy

```python
from matplotlib.pyplot as plt
from scipy.cluster.hierarchy import linkage, dendrogram
mergins = linkage(samples, method='complete')
dendrogram(mergings, labels=country_names, leaf_rotation=90, leaf_font_size=6)
plt.show()
```

The linkage method defines how the distance between clusters is measured. 

In complete linkage, the distance between clusters is the distance between the furthest points of the clusters.
In single linkage, the distance between clusters is the distance between the closest points of the clusters.

We can extract cluster labels using fcluster

```python
from scipy.cluster,hierarchy import linkage
mergings = linkage(samples, method='complete')
from scipy.cluster.hierarchy import fcluster
labels = fcluster(mergings, 15, criterion='distance')
print(labels)
```

```python
import pandas as pd
pairs = pd.DataFrame({'labels': labels, 'countries': country_names})
print(pairs.sort_values('labels'))
```


t-SNE is t-distributed stochastic neighbour embedding

This maps samples from their high dimensional spaces to 2 (or 3) dimensions

This represents the distance between samples

```python
import matplotlib.pyplot as plt
from sklearn.manifold import TSNE
model = TSNE(learning_rate=100)
transformed = model.fit_transform(samples)
xs = transformed[:,0]
ys = transformed[:,1]
plt.scatter(xs, ys, c=species)
plt.show()
```

t-SNE only has fit_transform(), not separate functions

t-SNE learning rate might need to be experimented with for different datasets [50,200]

Also, t-SNE plot axis have no interpretable meaning, and 3 computations of the same code might result in different orientation of results